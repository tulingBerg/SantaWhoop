void serial_init(void);


