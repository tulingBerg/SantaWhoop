
void gpio_init(void);
int gpio_init_fpv(void);



