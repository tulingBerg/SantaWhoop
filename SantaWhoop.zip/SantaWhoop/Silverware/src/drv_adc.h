
void adc_init(void);
float adc_read(int channel);

