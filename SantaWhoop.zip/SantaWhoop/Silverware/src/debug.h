

typedef struct debug
{
	int gyroid;
	float vbatt_comp;
	float adcfilt;
	float totaltime;	
	float timefilt;
    float adcreffilt;
	float cpu_load;
} debug_type;




