

void rx_init(void);
void checkrx( void);
#if defined(RX_DSMX_2048) || defined(RX_DSM2_1024)
void rx_spektrum_bind(void);
#endif


































